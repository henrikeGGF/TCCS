document.addEventListener('DOMContentLoaded', function() {
    // Brazilian slang words
    const searches = [
        "Tamo junto", "De boa", "Daora", "Role", "Busão", 
        "Mó", "Tô ligado", "Xavecar", "Caraio", "Mermão",
        "Firmeza", "Bala", "Zoeira", "Mina", "Véi",
        "Pagar mico", "Caô", "Arrochar", "Bico", "Bater papo"
    ];
    
    const searchList = document.getElementById('searchList');
    
    // Add search items to the list
    searches.forEach(search => {
        const searchItem = document.createElement('div');
        searchItem.className = 'search-item bg-white p-3 rounded-lg shadow-sm cursor-pointer flex items-center';
        searchItem.innerHTML = `
            <i class="fas fa-hashtag text-blue-500 mr-2"></i>
            <span class="text-blue-800">${search}</span>
        `;
        searchList.appendChild(searchItem);
        
        // Add click event to search items
        searchItem.addEventListener('click', function() {
            alert(`Você clicou em: ${search}`);
        });
    });
    
    // Toggle password visibility
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('passwordInput');
    
    togglePassword.addEventListener('click', function() {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        this.innerHTML = type === 'password' ? '<i class="fas fa-eye"></i>' : '<i class="fas fa-eye-slash"></i>';
    });
    
    // Edit button functionality
    const editButton = document.getElementById('editButton');
    const inputs = document.querySelectorAll('.profile-input');
    let isEditing = false;
    
    editButton.addEventListener('click', function() {
        isEditing = !isEditing;
        
        if (isEditing) {
            this.innerHTML = '<i class="fas fa-save"></i><span>Salvar Alterações</span>';
            inputs.forEach(input => {
                input.removeAttribute('readonly');
                input.style.backgroundColor = 'rgba(255, 255, 255, 0.2)';
            });
        } else {
            this.innerHTML = '<i class="fas fa-edit"></i><span>Editar Perfil</span>';
            inputs.forEach(input => {
                input.setAttribute('readonly', true);
                input.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
            });
            alert('Alterações salvas com sucesso!');
        }
    });
    
    // Initially set inputs to readonly
    inputs.forEach(input => {
        input.setAttribute('readonly', true);
    });
});


