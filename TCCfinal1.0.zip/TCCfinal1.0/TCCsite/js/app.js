var btnSignin = document.querySelector("#signin");
var btnSignup = document.querySelector("#signup");
var body = document.querySelector("body");

btnSignin.addEventListener("click", function () {
   body.className = "sign-in-js"; 
});

btnSignup.addEventListener("click", function () {
    body.className = "sign-up-js";
})
// Seleciona elementos
const signinBtn = document.querySelector("#signin");
const signupBtn = document.querySelector("#signup");
const container = document.querySelector(".container");

signinBtn.addEventListener("click", () => {
    container.classList.add("sign-in-js");
    container.classList.remove("sign-up-js");
});

signupBtn.addEventListener("click", () => {
    container.classList.add("sign-up-js");
    container.classList.remove("sign-in-js");
});

// Função para carregar usuários do localStorage
function getUsers() {
    return JSON.parse(localStorage.getItem("users")) || [];
}

// Função para salvar usuários no localStorage
function saveUsers(users) {
    localStorage.setItem("users", JSON.stringify(users));
}

// Cria usuários de teste se ainda não existirem
function createDefaultUsers() {
    let users = getUsers();

    if (!users.find(u => u.email === "admin@tvlb.com")) {
        users.push({ name: "Administrador", email: "admin@tvlb.com", password: "123456", role: "admin" });
    }
    if (!users.find(u => u.email === "user@tvlb.com")) {
        users.push({ name: "Usuário Teste", email: "user@tvlb.com", password: "123456", role: "user" });
    }

    saveUsers(users);
}
createDefaultUsers();

// --- CADASTRO ---
document.querySelector("#registerForm").addEventListener("submit", (e) => {
    e.preventDefault();

    const name = document.querySelector("#registerName").value.trim();
    const email = document.querySelector("#registerEmail").value.trim();
    const password = document.querySelector("#registerPassword").value.trim();

    let users = getUsers();

    if (users.some(u => u.email === email)) {
        alert("Este e-mail já está cadastrado!");
        return;
    }

    users.push({ name, email, password, role: "user" });
    saveUsers(users);

    alert("Conta criada com sucesso! Você já pode fazer login.");
    e.target.reset();
});

// --- LOGIN ---
document.querySelector("#loginForm").addEventListener("submit", (e) => {
    e.preventDefault();

    const email = document.querySelector("#loginEmail").value.trim();
    const password = document.querySelector("#loginPassword").value.trim();

    const users = getUsers();
    const user = users.find(u => u.email === email && u.password === password);

    if (user) {
        localStorage.setItem("loggedUser", JSON.stringify(user));
        alert(`Bem-vindo, ${user.name}!`);

        if (user.role === "admin") {
            window.location.href = "../TCCsite/php/add.php";
        } else {
            window.location.href = "../TCCsite/php/index.php";
        }
    } else {
        alert("E-mail ou senha incorretos!");
    }
});