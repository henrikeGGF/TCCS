<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../css2/style.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css"
        crossorigin="anonymous">
</head>
<body>
    <img src="../imagens_tcc/imgTVLBlogo-removebg-preview.png" alt="logo" class="img">
    <div class="container">
        
        <!-- CADASTRO -->
        <div class="content first-content">
            <div class="first-column">
                <h2 class="title title-primary">Bem-vindo!</h2>
                <p class="description description-primary">Já possui uma conta?</p>
                <p class="description description-primary">Clique aqui para entrar no T.V.L.B</p>
                <button id="signin" class="btn btn-primary">Entrar</button>
            </div>    
            <div class="second-column">
                <p class="description description-second">Ou crie uma nova conta:</p>
                <form id="registerForm" class="form">
                    <label class="label-input">
                        <i class="far fa-user icon-modify"></i>
                        <input type="text" id="registerName" placeholder="Nome" required>
                    </label>
                    
                    <label class="label-input">
                        <i class="far fa-envelope icon-modify"></i>
                        <input type="email" id="registerEmail" placeholder="Email" required>
                    </label>
                    
                    <label class="label-input">
                        <i class="fas fa-lock icon-modify"></i>
                        <input type="password" id="registerPassword" placeholder="Senha" required>
                    </label>
                    
                    <button type="submit" class="btn btn-second">Criar</button>        
                </form>
            </div>
        </div>

        <!-- LOGIN -->
        <div class="content second-content">
            <div class="first-column">
                <p class="description description-primary">Não possui uma conta?</p>
                <p class="description description-primary">Clique em criar para ter uma!</p>
                <button id="signup" class="btn btn-primary">Criar</button>
            </div>
            <div class="second-column">
                <p class="description description-second">Ou use uma conta existente:</p>
                <form id="loginForm" class="form">
                    <label class="label-input">
                        <i class="far fa-envelope icon-modify"></i>
                        <input type="email" id="loginEmail" placeholder="Email" required>
                    </label>
                
                    <label class="label-input">
                        <i class="fas fa-lock icon-modify"></i>
                        <input type="password" id="loginPassword" placeholder="Senha" required>
                    </label>
                
                    <button type="submit" class="btn btn-second">Entrar</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Container global para Toasts -->
    <div id="toastContainer"></div>

    <script>
        const container = document.querySelector('.container');
        const signinButton = document.getElementById('signin');
        const signupButton = document.getElementById('signup');
    
        // Função de alternar telas
        signinButton.addEventListener('click', () => {
            container.classList.add('sign-in-js');
            container.classList.remove('sign-up-js');
        });
    
        signupButton.addEventListener('click', () => {
            container.classList.add('sign-up-js');
            container.classList.remove('sign-in-js');
        });
    
        // ======= Funções de usuários =======
        function getUsers() {
            return JSON.parse(localStorage.getItem("users")) || [];
        }
    
        function saveUsers(users) {
            localStorage.setItem("users", JSON.stringify(users));
        }
    
        function createDefaultUsers() {
            let users = getUsers();
    
            if (!users.find(u => u.email === "admin@tvlb.com")) {
                users.push({ name: "Administrador", email: "admin@tvlb.com", password: "admin", role: "admin" });
            }
            if (!users.find(u => u.email === "user@tvlb.com")) {
                users.push({ name: "Usuário Teste", email: "user@tvlb.com", password: "user123", role: "user" });
            }
    
            saveUsers(users);
        }
        createDefaultUsers();
    
        // ======= Cadastro =======
        document.querySelector("#registerForm").addEventListener("submit", (e) => {
            e.preventDefault();
    
            const name = document.querySelector("#registerName").value.trim();
            const email = document.querySelector("#registerEmail").value.trim();
            const password = document.querySelector("#registerPassword").value.trim();
    
            if (!name || !email || !password) {
                alert("Preencha todos os campos!");
                return;
            }
    
            let users = getUsers();
            if (users.some(u => u.email === email)) {
                alert("Este e-mail já está cadastrado!");
                return;
            }
    
            users.push({ name, email, password, role: "user" });
            saveUsers(users);
    
            alert("Conta criada com sucesso! Faça login.");
            e.target.reset();
        });
    
        // ======= Login =======
        document.querySelector("#loginForm").addEventListener("submit", (e) => {
            e.preventDefault();
    
            const email = document.querySelector("#loginEmail").value.trim();
            const password = document.querySelector("#loginPassword").value.trim();
    
            const users = getUsers();
            const user = users.find(u => u.email === email && u.password === password);
    
            if (user) {
                localStorage.setItem("loggedUser", JSON.stringify(user));
    
                if (user.role === "admin") {
                    window.location.href = "../php/add.php";
                } else {
                    window.location.href = "../php/index.php";
                }
            } else {
                alert("E-mail ou senha incorretos!");
            }
        });
    </script>
<!-- 
<script src="login.js"></script> -->

</body>
</html>
