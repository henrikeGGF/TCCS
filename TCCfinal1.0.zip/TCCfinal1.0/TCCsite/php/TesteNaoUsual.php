<?php
// slang_search.php
// Simples buscador de gírias brasileiras usando SQLite + busca fuzzy em PHP.

// --- Config ---
$dbFile = __DIR__ . '/slangs.db';
$createIfMissing = true;

// --- Helpers ---
function normalize($s) {
    // deixa tudo minúsculo, remove acentos e espaços extras
    $s = mb_strtolower(trim($s), 'UTF-8');
    // translitera acentos
    $s = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
    // remove caracteres não alfanuméricos exceto espaço
    $s = preg_replace('/[^a-z0-9 ]+/', '', $s);
    // colapsa espaços
    $s = preg_replace('/\s+/', ' ', $s);
    return $s;
}

function ensureDb($dbFile) {
    global $createIfMissing;
    $isNew = !file_exists($dbFile);
    $pdo = new PDO('sqlite:' . $dbFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($isNew && $createIfMissing) {
        $pdo->exec("CREATE TABLE slangs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            slang TEXT NOT NULL,
            definition TEXT,
            example TEXT,
            normalized TEXT
        )");

        // Inserir amostra de gírias brasileiras com normalizações
        $samples = [
            ['mó', 'Usado para intensificar algo: "mó legal" = muito legal', 'Ex: Esse filme é mó daora.'],
            ['daora', 'Legal, bacana.', 'Ex: A festa foi daora.'],
            ['mano', 'Amigo / cara (informal).', 'Ex: E ai, mano?'],
            ['véio', 'Variante de "véio/véi" — usado como interjeição ou para pessoa', 'Ex: Véio, que história!'],
            ['firmeza', 'Tudo certo, combinado; também usado como saudação positiva', 'Ex: Firmeza, até amanhã.'],
            ['treta', 'Confusão, briga, problema.', 'Ex: Deu treta na reunião.'],
            ['zuera', 'Brincadeira, zoação.', 'Ex: Tava na zuera, não leve a sério.'],
            ['dar mole', 'Vacilar, ser descuidado.', 'Ex: Não dá mole com a senha.'],
            ['pagar mico', 'Passar vergonha.', 'Ex: Ele pagou mico na frente de todo mundo.'],
            ['caô', 'Mentira, desculpa, conversa fiada.', 'Ex: Isso é caô do começo ao fim.'],
            ['pitiú', 'Cheiro forte (geralmente de peixe).', 'Ex: Esse peixe tá com pitiú.'],
            //Norte
['pirão', 'Confusão, bagunça.', 'Ex: Deu pirão na reunião.'],
['aperreado', 'Apressado, aflito.', 'Ex: Tava todo aperreado para chegar.'],
['arretado', 'Bom, massa, excelente.', 'Ex: O show foi arretado!'],
['mangar', 'Zoar alguém, rir da pessoa.', 'Ex: Para de mangar de mim!'],
['cabuloso', 'Difícil, estranho ou impressionante.', 'Ex: Esse bicho é cabuloso.'],
['capado', 'Sem opção, limitado.', 'Ex: O sinal da internet tá capado.'],
['cuíra', 'Vontade intensa por algo.', 'Ex: Tô com cuíra de comerçaça.'],
['liso', 'Sem dinheiro.', 'Ex: Hoje tô liso.'],
['triângulo', 'Mentira exagerada.', 'Ex: Esse cara só conta triângulo.'],
['leso', 'Lento, desatento.', 'Ex: Tu é muito leso!'],
['esbarrar', 'Encontrar alguém por acaso.', 'Ex: Esbarrei com ele na rua.'],
['visagem', 'Fantasma, assombração.', 'Ex: Dizem que ali tem visagem.'],
['malungo', 'Parceiro, amigo.', 'Ex: Fala, malungo!'],
['falastrão', 'Pessoa que fala muito e faz pouco.', 'Ex: Esse cara é falastrão.'],
['piti', 'Ataque de raiva ou frescura.', 'Ex: Deu piti à toa.'],
['pequiá', 'Coisa grande demais.', 'Ex: Olha o pequiá desse bicho.'],
['abestado', 'Bobo, idiota.', 'Ex: Esse menino é abestado.'],
['bodar', 'Enjoar de algo.', 'Ex: Bodei esse filme.'],
['tirar onda', 'Zoar, brincar.', 'Ex: Tava tirando onda com ele.'],
['caruara', 'Erro, confusão.', 'Ex: Fiz uma caruara no trabalho.'],
['arreda', 'Sai da frente.', 'Ex: Arreda um pouco aí.'],
['maceta', 'Pedaço grande de algo.', 'Ex: Me dá uma maceta de bolo.'],
['jacre', 'Pessoa sem noção.', 'Ex: Aquele cara é jacre.'],
['pitiado', 'Com medo.', 'Ex: Tô pitiado dessa rua escura.'],
['bubuia', 'Flutuando na água.', 'Ex: Ficou só na bubuia.'],
['labutar', 'Trabalhar muito.', 'Ex: Hoje labutei demais.'],
['morgar', 'Desistir, cancelar.', 'Ex: Morgou de sair.'],
['bolar', 'Se esconder ou fugir.', 'Ex: Ele bolou dali.'],
['caído', 'Barato, fraco, sem graça.', 'Ex: Esse show tá caído.'],
['galalau', 'Pessoa muito alta.', 'Ex: Aquele galalau ali.'],
['xeleléu', 'Puxa-saco.', 'Ex: Ele é xeleléu do chefe.'],
['chibata', 'Muito bom.', 'Ex: A comida tava chibata.'],
['mozado', 'Namorando.', 'Ex: Tô mozado agora.'],
['sapeca-iaia', 'Criança levada.', 'Ex: Esse menino é sapeca-iaia.'],
['capenga', 'Algo improvisado, mal feito.', 'Ex: Essa cadeira tá capenga.'],
['barrigudo', 'Mentiroso.', 'Ex: Esse cara é barrigudo.'],
['morcegar', 'Ficar parado sem fazer nada.', 'Ex: Tava morcegando no sofá.'],
['calundu', 'Mau humor.', 'Ex: Tá de calundu hoje.'],
['pirraçar', 'Provocar.', 'Ex: Ele fica pirraçando o irmão.'],
['manjubinha', 'Pessoa fraca.', 'Ex: Tua desculpa é manjubinha.'],
['passar no prego', 'Ser enganado.', 'Ex: Passei no prego na compra.'],
['pai d’égua', 'Legal, massa.', 'Ex: Foi pai d’égua demais!'],
['de rocha', 'De verdade.', 'Ex: Falou de rocha.'],
['pixulí', 'Dinheiro.', 'Ex: Tô sem pixulí.'],
['migué', 'Enganação.', 'Ex: Deu migué e foi embora.'],
['nojento', 'Muito bom ou muito ruim (depende do tom).', 'Ex: Essa música é nojenta!'],
['foi-se embora', 'Desapareceu.', 'Ex: Sumiu, foi-se embora.'],
['matuto', 'Pessoa simples do interior.', 'Ex: É gente boa, mas matuto.'],
['cabulagem', 'Coisa esquisita.', 'Ex: Que cabulagem é essa?'],
//nordeste
['arretado', 'Incrível, muito bom, admirável.', 'Ex: O show foi arretado demais!'],
['oxente', 'Expressão de surpresa ou estranhamento.', 'Ex: Oxente, que história é essa?'],
['visse', 'Usado para reforço na fala, tipo “sabe?”.', 'Ex: É bom demais, visse.'],
['avoado', 'Distraído, desligado.', 'Ex: Ele vive avoado na aula.'],
['cabrunco', 'Alguém difícil ou bravo.', 'Ex: Esse cabrunco é arretado.'],
['aperreio', 'Aperto, preocupação, problema.', 'Ex: Tô num aperreio danado.'],
['cabra da peste', 'Pessoa valente, corajosa.', 'Ex: Esse menino é cabra da peste.'],
['mangar', 'Zoar alguém, tirar sarro.', 'Ex: Para de mangar de mim!'],
['fuleiragem', 'Bagunça, coisa mal feita.', 'Ex: Isso aí é fuleiragem!'],
['bucho cheio', 'Satisfeito depois de comer.', 'Ex: Tô de bucho cheio.'],
['lascar', 'Estragar, prejudicar.', 'Ex: Lascou tudo no final.'],
['matutar', 'Pensar, refletir.', 'Ex: Vou matutar sobre isso.'],
['abirobado', 'Louco, esquisito.', 'Ex: Esse cara é abirobado.'],
['se avexe não', 'Não se preocupe, calma.', 'Ex: Se avexe não, vai dar certo.'],
['peste', 'Usado como brincadeira ou surpresa.', 'Ex: Ô peste, chegou cedo hoje!'],
['dizer arrego', 'Desistir.', 'Ex: Ele disse arrego no meio do jogo.'],
['pirangueiro', 'Pessoa mão-de-vaca.', 'Ex: Esse cabra é pirangueiro demais.'],
['arengar', 'Brigar, discutir.', 'Ex: Eles vivem arengando.'],
['zuada', 'Barulho forte.', 'Ex: Que zuada é essa na rua?'],
['moiado', 'Molhado.', 'Ex: Cheguei todo moiado da chuva.'],
['marmota', 'Coisa feia ou esquisita.', 'Ex: Que marmota é essa?'],
['escroto', 'Muito ruim ou mal feito.', 'Ex: O plano foi escroto demais.'],
['firula', 'Frescura, enrolação.', 'Ex: Para de firula e resolve logo.'],
['chiado', 'Pessoa falante demais.', 'Ex: Esse menino é chiado.'],
['baiúca', 'Lugar pequeno e abafado.', 'Ex: Tava preso numa baiúca.'],
['pocar', 'Rachar de rir ou estourar algo.', 'Ex: Me pocando de rir.'],
['regar', 'Desistir e ir embora.', 'Ex: Ele regou na última hora.'],
['abufelar', 'Ficar zangado.', 'Ex: Ele se abufelou com a notícia.'],
['lapada', 'Copo de bebida forte.', 'Ex: Tomei uma lapada de cachaça.'],
['buxo', 'Barriga.', 'Ex: Comeu até o buxo doer.'],
['balaio', 'Mistura, bagunça.', 'Ex: Isso aí virou um balaio só.'],
['cabrunco', 'Alguém difícil ou rabugento.', 'Ex: Esse cabrunco não muda nunca.'],
['cangaia', 'Peso, trabalho difícil.', 'Ex: Essa tarefa é uma cangaia.'],
['catenga', 'Coisa ruim, sem graça.', 'Ex: Esse filme é catenga.'],
['panema', 'Pessoa azarada.', 'Ex: Sou panema demais, nada dá certo.'],
['lapado', 'Muito cheio ou muito alto.', 'Ex: O bar tava lapado de gente.'],
['desmantelo', 'Confusão geral.', 'Ex: A casa virou um desmantelo.'],
['trupicar', 'Tropeçar.', 'Ex: Trupiquei na calçada.'],
['danado', 'Usado como elogio ou reação.', 'Ex: Esse menino é danado!'],
['arretamento', 'Raiva ou brabeza.', 'Ex: Tava no arretamento ontem.'],
['botar boneco', 'Fazer festa, bagunça.', 'Ex: Ontem botaram boneco.'],
['desmantelar', 'Estragar tudo.', 'Ex: Desmantelou a bicicleta.'],
['tirar onda', 'Zoar ou se exibir.', 'Ex: Ficou tirando onda com o carro novo.'],
['molóide', 'Pessoa lenta, preguiçosa.', 'Ex: Esse cara é molóide.'],
['papocar', 'Aparecer em peso.', 'Ex: A galera papocou na festa.'],
['arretadíssimo', 'Muito bom.', 'Ex: O filme foi arretadíssimo!'],
['me arrenho', 'Expresso que algo é muito bom ou engraçado.', 'Ex: Me arrenho de rir com ele.'],
['embromação', 'Enrolação.', 'Ex: Isso é só embromação.'],
['oxê', 'Versão curta de oxente, surpresa.', 'Ex: Oxê, quem te chamou?'],
['vixe maria', 'Surpresa ou espanto.', 'Ex: Vixe Maria, que susto.'],
['cainho', 'Pouco, pequeno.', 'Ex: Só um cainho de açúcar.'],
//centro-oeste
['trem', 'Qualquer coisa ou objeto.', 'Ex: Pega aquele trem ali pra mim.'],
['uai', 'Expressão de surpresa ou dúvida.', 'Ex: Uai, cê não ia chegar cedo?'],
['sô', 'Usado para chamar ou terminar frase.', 'Ex: Cê tá bão, sô?'],
['bão', 'Bom.', 'Ex: Esse churrasco tá bão demais.'],
['arredar', 'Sair da frente, mover.', 'Ex: Arreda aí um pouquinho.'],
['piá', 'Menino, garoto.', 'Ex: Aquele piá é esperto.'],
['guri', 'Menino.', 'Ex: O guri tá correndo demais.'],
['dar perdido', 'Sumir sem avisar.', 'Ex: Ele deu perdido o dia inteiro.'],
['véi', 'Amigo, parceiro.', 'Ex: E aí, véi, suave?'],
['parrudo', 'Forte, musculoso.', 'Ex: O cara é parrudo.'],
['trampo', 'Trabalho.', 'Ex: Tenho trampo hoje cedo.'],
['chegado', 'Amigo próximo.', 'Ex: Ele é meu chegado.'],
['maloqueiro', 'Bagunceiro, que causa.', 'Ex: Esses meninos são maloqueiros.'],
['muvuca', 'Bagunça cheia de gente.', 'Ex: Tava uma muvuca na praça.'],
['embolar', 'Bagunçar.', 'Ex: Embolou tudo os papéis.'],
['pocar', 'Estourar / dar risada.', 'Ex: Poca esse balão aí.'],
['nóis', 'Nós (maneira informal).', 'Ex: Nóis vai lá amanhã.'],
['tá osso', 'Tá difícil.', 'Ex: Estudar pra prova tá osso.'],
['rolê', 'Passeio, saída.', 'Ex: Bora dar um rolê.'],
['catireiro', 'Gosto, interesse, quem negocia.', 'Ex: Ele é catireiro, compra e vende de tudo.'],
['cabreiro', 'Desconfiado.', 'Ex: Fiquei cabreiro com a proposta.'],
['pegar ar', 'Ficar bravo.', 'Ex: Ele pegou ar comigo.'],
['fritar', 'Ficar pensando demais.', 'Ex: Passei a noite fritando nisso.'],
['zuado', 'Estragado, ruim.', 'Ex: Meu celular tá zuado.'],
['cabuloso', 'Muito bom ou muito estranho.', 'Ex: Essa música é cabulosa.'],
['bater perna', 'Andar muito.', 'Ex: Fiquei batendo perna o dia inteiro.'],
['bamburra', 'Dar sorte.', 'Ex: Bamburrou e ganhou tudo.'],
['morgar', 'Desanimar, desistir.', 'Ex: Morguei de sair.'],
['garrar', 'Agarrar, prender.', 'Ex: A blusa garrou no fio.'],
['corre', 'Aventura, tarefa, missão.', 'Ex: Tenho um corre pra resolver.'],
['bretear', 'Correr atrás intensamente.', 'Ex: Tô bretando pra pagar as contas.'],
['marrento', 'Metido, convencido.', 'Ex: Tá marrento demais.'],
['embromar', 'Enrolar.', 'Ex: Tá embromando pra começar.'],
['reparar', 'Olhar atentamente.', 'Ex: Repara nisso aqui.'],
['moiá', 'Molhar.', 'Ex: Moiei todo na chuva.'],
['dar bode', 'Ficar ruim, chato.', 'Ex: O rolê deu bode.'],
['gororoba', 'Comida feia ou ruim.', 'Ex: Que gororoba é essa?'],
['pitar', 'Fumar.', 'Ex: Saiu pra pitar um cigarro.'],
['banguela', 'Sem dentes ou sem velocidade (carro).', 'Ex: O carro desceu banguela.'],
['munheca', 'Homem ou mulher com trejeitos afeminados.', 'Ex: Ele é meio munheca.'],
['bagaceira', 'Confusão, sujeira.', 'Ex: A festa virou bagaceira.'],
['cafuçu', 'Pessoa grosseira.', 'Ex: Que cafuçu ignorante!'],
['trairagem', 'Traição, sacanagem.', 'Ex: Isso foi trairagem contigo.'],
['papo reto', 'Falar sério.', 'Ex: Tô falando papo reto aqui.'],
['suave', 'Tranquilo.', 'Ex: Tá suave, pode vim.'],
['rala peito', 'Ir embora rápido.', 'Ex: Rala peito antes que chova.'],
['pocar de rir', 'Rachar de rir.', 'Ex: Tava pocando de rir ontem.'],
['pão-duro', 'Mão-de-vaca.', 'Ex: Ele é pão-duro demais.'],
['treta', 'Confusão, briga.', 'Ex: Deu treta na sala.'],
['chavear', 'Trancar.', 'Ex: Chaveia a porta quando sair.'],
['perrengue', 'Situação difícil.', 'Ex: Passei perrengue no ônibus.'],
//sudeste
['mano', 'Amigo, colega.', 'Ex: E aí, mano, tranquilo?'],
['véi/véio', 'Amigo, conhecido, também usado como interjeição.', 'Ex: Véio, olha isso!'],
['daora', 'Legal, bacana.', 'Ex: O filme foi daora demais.'],
['nóia', 'Paranoia ou pessoa estranha.', 'Ex: Que nóia foi aquela?'],
['maluco', 'Cara, pessoa.', 'Ex: Esse maluco é engraçado.'],
['zoar', 'Tirar sarro, brincar.', 'Ex: Só tava zoando.'],
['zoado', 'Ruim, estranho, quebrado.', 'Ex: Meu celular tá zoado.'],
['bolado', 'Bravo, chateado ou impressionado.', 'Ex: Fiquei bolado com isso.'],
['dar ruim', 'Dar errado.', 'Ex: O plano deu ruim.'],
['dar bom', 'Dar certo.', 'Ex: A ideia deu bom demais.'],
['tá tirando?', 'Expressão de indignação.', 'Ex: Tá tirando comigo?'],
['papo reto', 'Falar sério, sem zoeira.', 'Ex: Papo reto, não curti.'],
['migué', 'Desculpa, enrolação.', 'Ex: Ele deu migué e foi embora.'],
['pagar pau', 'Admirar muito alguém.', 'Ex: Ele paga pau pra ela.'],
['bater perna', 'Andar muito.', 'Ex: Fiquei batendo perna no shopping.'],
['chapado', 'Muito cansado, drogado ou impressionado.', 'Ex: Tô chapado de sono.'],
['treta', 'Confusão, briga.', 'Ex: Deu treta no jogo.'],
['bagulho', 'Coisa, objeto, situação.', 'Ex: Pega aquele bagulho ali.'],
['brother', 'Amigo.', 'Ex: Ele é meu brother.'],
['mané', 'Pessoa boba, sem noção.', 'Ex: Seu mané!'],
['zoeira', 'Brincadeira.', 'Ex: Tudo isso é zoeira.'],
['tretar', 'Brigar.', 'Ex: Eles tretaram na escola.'],
['mó', 'Muito.', 'Ex: Esse carro é mó caro.'],
['vacilão', 'Pessoa sem palavra, que erra feio.', 'Ex: Ele foi vacilão demais.'],
['mandado', 'Pessoa boba, que obedece tudo.', 'Ex: Ele é mandado por todo mundo.'],
['dar rolê', 'Sair, passear.', 'Ex: Bora dar um rolê hoje.'],
['bizarro', 'Estranho ou impressionante.', 'Ex: Aquilo foi bizarro.'],
['tenso', 'Complicado, nervoso.', 'Ex: Situação tensa demais.'],
['gambiarra', 'Jeitinho improvisado.', 'Ex: Fiz uma gambiarra no fio.'],
['trampo', 'Trabalho.', 'Ex: Tenho trampo agora.'],
['vish', 'Expressão de surpresa.', 'Ex: Vish, deu ruim.'],
['deu ruim', 'Deu errado.', 'Ex: O plano deu ruim.'],
['meter o louco', 'Fazer algo arriscado ou inesperado.', 'Ex: Meteu o louco e saiu correndo.'],
['chave', 'Estiloso.', 'Ex: Ele veio chave hoje.'],
['tipo assim', 'Expressão de explicação.', 'Ex: Tipo assim, foi sem querer.'],
['bafafá', 'Confusão.', 'Ex: Teve bafafá na festa.'],
['zuar o plantão', 'Fazer bagunça no serviço.', 'Ex: Os caras zoaram o plantão.'],
['vibe', 'Clima, sensação.', 'Ex: A vibe da festa tava boa.'],
['suave', 'Tranquilo.', 'Ex: Tá suave, pode vir.'],
['de boa', 'Tranquilo, sem estresse.', 'Ex: Tô de boa hoje.'],
['parça', 'Amigo, parceiro.', 'Ex: E aí, parça?'],
['vacilo', 'Erro bobo.', 'Ex: Dei vacilo na prova.'],
['resenha', 'Conversa legal, zoeira.', 'Ex: Tava rolando resenha.'],
['pistar', 'Fazer sucesso, se mostrar.', 'Ex: Ele ficou pistando no baile.'],
['brega', 'Feio, fora de moda.', 'Ex: Aquele tênis é brega.'],
['barrigada', 'Mentira grande.', 'Ex: Contou uma barrigada.'],
['quebrada', 'Bairro periférico.', 'Ex: Moro lá na quebrada.'],
['malandro', 'Esperto, ligeiro.', 'Ex: Ele é malandro, não cai.'],
['dar linha', 'Ir embora rápido.', 'Ex: Vou dar linha que já tá tarde.'],
['bombril', 'Que faz muitas funções.', 'Ex: Eu sou bombril lá no trabalho.'],
['zicado', 'Azarado.', 'Ex: Sou zicado demais.'],
//sul
['bah', 'Expressão típica de surpresa, admiração ou susto.', 'Ex: Bah, que loucura isso!'],
['tri', 'Muito, demais.', 'Ex: O filme foi tri legal.'],
['guri', 'Menino.', 'Ex: O guri tá brincando ali.'],
['guria', 'Menina.', 'Ex: Aquela guria é minha amiga.'],
['capaz', 'Expressão de surpresa, negação.', 'Ex: Capaz que ele fez isso!'],
['barbaridade', 'Surpresa ou indignação.', 'Ex: Barbaridade, tá frio demais.'],
['tchê', 'Chamado ou expressão de identificação.', 'Ex: Bah, tchê, que dia corrido!'],
['tri-legal', 'Muito bom.', 'Ex: O show foi tri-legal.'],
['mala', 'Pessoa chata.', 'Ex: Aquele cara é uma mala.'],
['chinelão', 'Pessoa sem vergonha, mal educada.', 'Ex: Não seja chinelão.'],
['macanudo', 'Legal, gente fina.', 'Ex: Ele é macanudo demais.'],
['galdério', 'Gaúcho tradicionalista.', 'Ex: Meu tio é galdério raiz.'],
['trem', 'Coisa, objeto qualquer.', 'Ex: Passa aquele trem pra mim.'],
['prenda', 'Mulher jovem ou moça bonita (gaúcho).', 'Ex: A prenda tava linda no baile.'],
['capaz nada', 'Claro que não.', 'Ex: Capaz nada que isso é verdade.'],
['faceiro', 'Feliz, cheio de si.', 'Ex: Ficou faceiro com o elogio.'],
['baita', 'Grande, excelente.', 'Ex: Comprou um baita carro.'],
['grosso', 'Pessoa rude, sem educação.', 'Ex: Não seja grosso.'],
['bah, mas', 'Intensifica comentário.', 'Ex: Bah, mas tá frio!'],
['de boaça', 'Muito tranquilo.', 'Ex: Tava de boaça na festa.'],
['sapeco', 'Rápido ou esperto.', 'Ex: O guri é sapeco.'],
['chê', 'Outra forma de “tchê”.', 'Ex: Ô chê, que demora!'],
['cuera', 'Pessoa nova, inexperiente.', 'Ex: Esse piá é cuera ainda.'],
['piá', 'Garoto, menino.', 'Ex: O piá tá na rua.'],
['bagual', 'Pessoa rústica do campo / algo forte.', 'Ex: Esse cavalo é bagual.'],
['vivente', 'Pessoa, indivíduo.', 'Ex: Quem é aquele vivente?'],
['louco de especial', 'Muito bom.', 'Ex: O show tava louco de especial.'],
['tri massa', 'Muito bom, muito legal.', 'Ex: O evento tava tri massa.'],
['junta-trapos', 'Casar ou morar junto.', 'Ex: Eles vão juntar trapos.'],
['cacetinho', 'Pão francês.', 'Ex: Compra um cacetinho ali na padaria.'],
['chimas', 'Chimarrão.', 'Ex: Vamos tomar um chimas.'],
['guriazinha', 'Moça jovem.', 'Ex: Conheci uma guriazinha gente boa.'],
['coisarada', 'Muitas coisas juntas.', 'Ex: Tava cheio de coisarada no chão.'],
['trilegal', 'Muito legal.', 'Ex: Foi trilegal te ver.'],
['barbaridade velha', 'Expressão forte de espanto.', 'Ex: Barbaridade velha, que frio!'],
['mas bah', 'Surpresa/enfado.', 'Ex: Mas bah, que trânsito.'],
['garrão', 'Alimento barato / comida simples.', 'Ex: Hoje tem garrão no almoço.'],
['gaudério', 'Gaúcho tradicional ou peão.', 'Ex: O gaudério chegou a cavalo.'],
['prenda linda', 'Mulher bonita.', 'Ex: Que prenda linda naquela festa.'],
['arre', 'Expressão de irritação.', 'Ex: Arre, que demora!'],
['se atucanar', 'Ficar nervoso, apressado.', 'Ex: Não se atucana.'],
['sestroso', 'Desconfiado, difícil.', 'Ex: Esse bicho é sestroso.'],
['pila', 'Dinheiro, real.', 'Ex: Custa 10 pila.'],
['gurizada', 'Grupo de jovens.', 'Ex: A gurizada chegou cedo.'],
['judiar', 'Maltratar / dificultar.', 'Ex: O frio judiou de todo mundo.'],
['dar barbada', 'Dar vantagem, facilitar.', 'Ex: O vendedor me deu barbada.'],
['bah, capaz', 'Surpresa descrente.', 'Ex: Bah, capaz que isso é verdade!'],
['chinelagem', 'Atitude de mau gosto.', 'Ex: Chegar atrasado foi chinelagem.'],
['meter ficha', 'Acelerar, continuar com força.', 'Ex: Mete ficha no trabalho.'],
['patrola', 'Pessoa muito alta.', 'Ex: A menina é uma patrola.'
],
['sarado', 'Fortão, corpo definido.', 'Ex: O guri tá sarado.'],
['sarandear', 'Passear sem rumo.', 'Ex: Tava sarandeando pelo centro.'],
            // adicione mais conforme quiser
        ];

        $stmt = $pdo->prepare("INSERT INTO slangs (slang, definition, example, normalized) VALUES (:slang, :definition, :example, :normalized)");
        foreach ($samples as $row) {
            $stmt->execute([
                ':slang' => $row[0],
                ':definition' => $row[1],
                ':example' => $row[2],
                ':normalized' => normalize($row[0])
            ]);
        }
    }

    return $pdo;
}

// --- main ---
$pdo = ensureDb($dbFile);

$term = isset($_GET['q']) ? trim($_GET['q']) : '';
$threshold = isset($_GET['threshold']) ? floatval($_GET['threshold']) : 0.45; // 0..1 para similaridade fuzzy
$results = [];

if ($term !== '') {
    $termNorm = normalize($term);

    // 1) busca direta por LIKE em slang ou normalized (mais rápida)
    $like = '%' . str_replace(' ', '%', $termNorm) . '%';
    $stmt = $pdo->prepare("SELECT * FROM slangs WHERE normalized LIKE :like OR slang LIKE :like");
    $stmt->execute([':like' => $like]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 2) buscar todos e calcular distância (para fuzzy), se poucos resultados, amplia
    if (count($rows) < 1) {
        $rows = $pdo->query("SELECT * FROM slangs")->fetchAll(PDO::FETCH_ASSOC);
    }

    // calcula similaridade (1 - normalized_levenshtein)
    foreach ($rows as $r) {
        $sNorm = normalize($r['slang'] . ' ' . $r['definition']); // considera também a definição no cálculo
        // distância de levenshtein entre termos normalizados
        $distance = levenshtein($termNorm, $sNorm);
        // normalizar distancia em similaridade entre 0 e 1
        $maxLen = max(mb_strlen($termNorm), mb_strlen($sNorm), 1);
        $similarity = 1 - ($distance / $maxLen);
        // também checar ocorrência direta de palavra
        if (strpos($sNorm, $termNorm) !== false) {
            $similarity = max($similarity, 0.95);
        }
        $r['similarity'] = round($similarity, 3);
        $results[] = $r;
    }

    // ordenar por similaridade decrescente
    usort($results, function($a, $b) {
        return $b['similarity'] <=> $a['similarity'];
    });

    // filtrar por threshold
    $results = array_filter($results, function($r) use ($threshold) {
        return $r['similarity'] >= $threshold;
    });

    // limitar resultados
    $results = array_slice($results, 0, 30);
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title>Buscador de Gírias Brasileiras</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
body { font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial; padding: 24px; background:#f7f7fb; color:#222 }
.container { max-width:800px; margin:0 auto; background:#fff; padding:20px; border-radius:10px; box-shadow:0 6px 24px rgba(0,0,0,0.06) }
h1 { margin-top:0 }
label { display:block; margin-top:12px; font-weight:600 }
input[type=text], input[type=number] { width:100%; padding:10px; border-radius:8px; border:1px solid #ddd; margin-top:6px }
button { margin-top:10px; padding:10px 14px; border-radius:8px; border:none; background:#2563eb; color:#fff; cursor:pointer }
.result { padding:12px; border-radius:8px; background:#fafafa; border:1px solid #eee; margin-top:10px }
.small { font-size:0.9rem; color:#555 }
.code { font-family:monospace; background:#eee; padding:2px 6px; border-radius:4px }
.badge { float:right; background:#111827; color:#fff; padding:4px 8px; border-radius:999px; font-size:0.8rem }
</style>
</head>
<body>
<div class="container">
    <h1>Buscador de Gírias Brasileiras</h1>
    <form method="get" action="">
        <label for="q">Digite uma palavra (ex.: mano, treta, moca):</label>
        <input id="q" name="q" type="text" value="<?= htmlspecialchars($term) ?>" placeholder="Buscar gírias...">

        <label for="threshold">Sensibilidade fuzzy (0 = muitos resultados / 1 = só muito parecido)</label>
        <input id="threshold" name="threshold" type="number" min="0" max="1" step="0.05" value="<?= htmlspecialchars($threshold) ?>">

        <button type="submit">Pesquisar</button>
    </form>

    <?php if ($term === ''): ?>
        <p class="small">Digite um termo e pressione "Pesquisar". O sistema compara com gírias guardadas no banco SQLite e usa busca aproximada também.</p>
    <?php else: ?>
        <p class="small">Resultados para <span class="code"><?= htmlspecialchars($term) ?></span> — encontrados <?= count($results) ?> resultado(s) (threshold <?= $threshold ?>)</p>

        <?php if (count($results) === 0): ?>
            <div class="result"><em>Nenhuma gíria encontrada. Tente reduzir o threshold ou procurar uma palavra similar.</em></div>
        <?php else: ?>
            <?php foreach ($results as $r): ?>
                <div class="result">
                    <div style="overflow:hidden">
                        <strong><?= htmlspecialchars($r['slang']) ?></strong>
                        <span class="badge"><?= htmlspecialchars($r['similarity']) ?></span>
                    </div>
                    <div class="small"><?= htmlspecialchars($r['definition']) ?></div>
                    <?php if (!empty($r['example'])): ?>
                        <div style="margin-top:8px"><em><?= htmlspecialchars($r['example']) ?></em></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    <?php endif; ?>

    <hr>
    <p class="small">Dicas: adicione mais gírias inserindo linhas na tabela <code>slangs</code> do arquivo <code>slangs.db</code> (SQLite). Se quiser, posso gerar um script para importar um CSV maior.</p>
</div>
</body>
</html>
