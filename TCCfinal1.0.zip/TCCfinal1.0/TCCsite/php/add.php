<?php

// Adinar gitias Aqui

require 'config.php';

function normalize($s) {
    $s = mb_strtolower(trim($s), 'UTF-8');
    $s = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
    $s = preg_replace('/[^a-z0-9 ]+/', '', $s);
    $s = preg_replace('/\s+/', ' ', $s);
    return $s;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $slang = $_POST['slang'] ?? '';
    $definition = $_POST['definition'] ?? '';
    $example = $_POST['example'] ?? '';
    $normalized = normalize($slang);

    $stmt = $pdo->prepare("INSERT INTO slangs (slang, definition, example, normalized) VALUES (?, ?, ?, ?)");
    $stmt->execute([$slang, $definition, $example, $normalized]);

    header("Location: add.php");
    exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Adicionar Gíria</title>
<style>
body { font-family: sans-serif; padding:20px; background:#f7f7fb; }
.container { max-width:700px; margin:auto; background:#fff; padding:20px; border-radius:10px; }
input, textarea, button { width:100%; padding:10px; margin-top:10px; }
</style>
</head>
<body>
<div class="container">
    <h1>Adicionar Gíria</h1>
    <form method="post">
        <input type="text" name="slang" placeholder="Gíria" required>
        <textarea name="definition" placeholder="Exemplo de uso"></textarea>
        <textarea name="example" placeholder="Definição"></textarea>
        <button type="submit">Salvar</button>
    </form>
    <hr>
    <a href="index.php">Voltar</a>
</div>
</body>
</html>
