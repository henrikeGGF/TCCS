<?php
$host = "localhost";
$dbname = "girias_db";
$user = "root"; // altere se necessário
$pass = "";     // altere se necessário

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
} catch (Exception $e) {
    die("Erro ao conectar: " . $e->getMessage());
}
