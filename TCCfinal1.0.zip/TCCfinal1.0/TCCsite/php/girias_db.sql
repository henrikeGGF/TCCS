-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 18/11/2025 às 01:04
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `girias_db`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `slangs`
--

CREATE TABLE `slangs` (
  `id` int(11) NOT NULL,
  `slang` varchar(100) NOT NULL,
  `definition` text DEFAULT NULL,
  `example` text DEFAULT NULL,
  `normalized` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `slangs`
--

INSERT INTO `slangs` (`id`, `slang`, `definition`, `example`, `normalized`) VALUES
(3, 'mó', 'Usado para intensificar algo: \"mó legal\" = muito legal', 'Ex: Esse filme é mó daora.', 'sudeste'),
(4, 'daora', 'Legal, bacana.', 'Ex: A festa foi daora.', 'sudeste'),
(5, 'mano', 'Amigo / cara (informal).', 'Ex: E ai, mano?', 'sudeste'),
(6, 'véio/véio', 'Amigo ou interjeição.', 'Ex: Véio, olha isso!', 'sudeste'),
(7, 'firmeza', 'Tudo certo, combinado.', 'Ex: Firmeza, até amanhã.', 'sudeste'),
(8, 'treta', 'Confusão, briga.', 'Ex: Deu treta na reunião.', 'sudeste'),
(9, 'zuera', 'Brincadeira, zoação.', 'Ex: Tava na zuera.', 'sudeste'),
(10, 'dar mole', 'Vacilar.', 'Ex: Não dá mole com a senha.', 'sudeste'),
(11, 'pagar mico', 'Passar vergonha.', 'Ex: Ele pagou mico.', 'sudeste'),
(12, 'caô', 'Mentira.', 'Ex: Isso é caô.', 'sudeste'),
(13, 'mó', 'Muito.', 'Ex: Esse carro é mó caro.', 'sudeste'),
(14, 'vacilão', 'Pessoa sem palavra.', 'Ex: Ele foi vacilão.', 'sudeste'),
(15, 'mandado', 'Pessoa que obedece tudo.', 'Ex: Ele é mandado.', 'sudeste'),
(16, 'dar rolê', 'Sair.', 'Ex: Bora dar um rolê.', 'sudeste'),
(17, 'bizarro', 'Estranho.', 'Ex: Aquilo foi bizarro.', 'sudeste'),
(18, 'tenso', 'Complicado.', 'Ex: Situação tensa.', 'sudeste'),
(19, 'gambiarra', 'Jeitinho improvisado.', 'Ex: Fiz uma gambiarra.', 'sudeste'),
(20, 'trampo', 'Trabalho.', 'Ex: Tenho trampo hoje.', 'sudeste'),
(21, 'vish', 'Expressão de surpresa.', 'Ex: Vish, deu ruim.', 'sudeste'),
(22, 'dar ruim', 'Dar errado.', 'Ex: Deu ruim.', 'sudeste'),
(23, 'meter o louco', 'Fazer algo inesperado.', 'Ex: Meteu o louco.', 'sudeste'),
(24, 'chave', 'Estiloso.', 'Ex: Veio chave.', 'sudeste'),
(25, 'tipo assim', 'Expressão.', 'Ex: Tipo assim...', 'sudeste'),
(26, 'bafafá', 'Confusão.', 'Ex: Teve bafafá.', 'sudeste'),
(27, 'zuar o plantão', 'Fazer bagunça no serviço.', 'Ex: Zoaram o plantão.', 'sudeste'),
(28, 'vibe', 'Clima', 'Ex: Boa vibe.', 'sudeste'),
(29, 'suave', 'Tranquilo.', 'Ex: Tá suave.', 'sudeste'),
(30, 'de boa', 'Tranquilo.', 'Ex: Tô de boa.', 'sudeste'),
(31, 'parça', 'Amigo.', 'Ex: E aí, parça?', 'sudeste'),
(32, 'vacilo', 'Erro bobo.', 'Ex: Dei vacilo.', 'sudeste'),
(33, 'resenha', 'Conversa divertida.', 'Ex: Tava rolando resenha.', 'sudeste'),
(34, 'pistar', 'Se exibir.', 'Ex: Pistando no baile.', 'sudeste'),
(35, 'brega', 'Feio.', 'Ex: É brega.', 'sudeste'),
(36, 'barrigada', 'Mentira grande.', 'Ex: Contou uma barrigada.', 'sudeste'),
(37, 'quebrada', 'Bairro periférico.', 'Ex: Moro na quebrada.', 'sudeste'),
(38, 'malandro', 'Esperto.', 'Ex: Ele é malandro.', 'sudeste'),
(39, 'dar linha', 'Ir embora rápido.', 'Ex: Vou dar linha.', 'sudeste'),
(40, 'bombril', 'Quem faz tudo.', 'Ex: Sou bombril no trampo.', 'sudeste'),
(41, 'zicado', 'Azarado.', 'Ex: Sou zicado.', 'sudeste'),
(42, 'pitiú', 'Cheiro forte, geralmente ruim.', 'Ex: Esse peixe tá com pitiú.', 'norte'),
(43, 'cumadi', 'Forma de chamar amiga / comadre.', 'Ex: Ô cumadi, vem cá!', 'norte'),
(44, 'marreteiro', 'Vendedor ambulante.', 'Ex: O marreteiro passou vendendo fruta.', 'norte'),
(45, 'tapioqueira', 'Pessoa que faz/vende tapioca.', 'Ex: A tapioqueira já chegou.', 'norte'),
(46, 'aperreado', 'Apressado ou agoniado.', 'Ex: Tô aperreado demais hoje.', 'norte'),
(47, 'fiado', 'Compra que será paga depois.', 'Ex: Tem como fazer fiado?', 'norte'),
(48, 'acunha', 'Grito de animação, chamado ou aviso.', 'Ex: Acunha, meu povo!', 'norte'),
(49, 'égua', 'Expressão surpresa ou espanto.', 'Ex: Égua, que calor!', 'norte'),
(50, 'pirão', 'Mistura líquida de farinha com caldo.', 'Ex: Fiz um pirão gostoso.', 'norte'),
(51, 'cabaré', 'Confusão ou bagunça.', 'Ex: Virou um cabaré.', 'norte'),
(52, 'puxirum', 'Ajuda coletiva.', 'Ex: Fizemos um puxirum pra limpar o espaço.', 'norte'),
(53, 'xodon', 'Pessoa amada.', 'Ex: Meu xodó chegou.', 'norte'),
(54, 'bichim', 'Forma carinhosa de falar com alguém.', 'Ex: Ô bichim, vem cá.', 'norte'),
(55, 'maloqueiro', 'Pessoa bagunceira.', 'Ex: Aquele ali é maloqueiro.', 'norte'),
(56, 'quengo', 'Cabeça.', 'Ex: Bati o quengo ali.', 'norte'),
(57, 'arretado', 'Corajoso ou animado.', 'Ex: Ele é arretado demais.', 'norte'),
(58, 'matutagem', 'Trapaça.', 'Ex: Tem matutagem nesse negócio.', 'norte'),
(59, 'prego', 'Pessoa chata.', 'Ex: Ele é um prego.', 'norte'),
(60, 'enxerido', 'Intrometido.', 'Ex: Para de ser enxerido.', 'norte'),
(61, 'papo reto', 'Falar a verdade.', 'Ex: Vou te falar papo reto.', 'norte'),
(62, 'abestado', 'Bobo, lerdo.', 'Ex: Tu és abestado?', 'norte'),
(63, 'pirracento', 'Teimoso.', 'Ex: Esse menino é pirracento.', 'norte'),
(64, 'apipocar', 'Começar de repente.', 'Ex: A chuva apipocou.', 'norte'),
(65, 'cabuloso', 'Assustador.', 'Ex: Esse lugar é cabuloso.', 'norte'),
(66, 'fuxico', 'Fofoquinha.', 'Ex: Tão fazendo fuxico.', 'norte'),
(67, 'arar', 'Resmungar.', 'Ex: Ele ficou arando sozinho.', 'norte'),
(68, 'pé de pato', 'Pessoa estabanada.', 'Ex: Tu é pé de pato demais.', 'norte'),
(69, 'jururu', 'Triste, desanimado.', 'Ex: Fiquei jururu hoje.', 'norte'),
(70, 'fiapo', 'Pessoa muito magra.', 'Ex: Ele é um fiapo.', 'norte'),
(71, 'papudim', 'Pessoa barrigudinha.', 'Ex: Meu tio é papudim.', 'norte'),
(72, 'me arrespeite', 'Pedido de respeito.', 'Ex: Me arrespeite, rapaz.', 'norte'),
(73, 'lamparina', 'Pessoa muito branca.', 'Ex: Tu é uma lamparina.', 'norte'),
(74, 'cacunda', 'Costas.', 'Ex: Doeu a cacunda.', 'norte'),
(75, 'caruara', 'Doido, confuso.', 'Ex: Ele ficou caruara.', 'norte'),
(76, 'gamar', 'Gostar muito.', 'Ex: Gamo nesse doce.', 'norte'),
(77, 'piti', 'Ataque emocional.', 'Ex: Deu piti à toa.', 'norte'),
(78, 'arretado', 'Algo muito bom, forte ou alguém corajoso.', 'Ex: O show foi arretado demais!', 'nordeste'),
(79, 'aperreado', 'Apressado, angustiado.', 'Ex: Tô aperreado com as contas.', 'nordeste'),
(80, 'oxente', 'Expressão de surpresa.', 'Ex: Oxente, que história é essa?', 'nordeste'),
(81, 'visse', 'Usado para reforçar a fala.', 'Ex: Tá quente hoje, visse?', 'nordeste'),
(82, 'mangá', 'Zoar alguém.', 'Ex: Tão mangando de mim.', 'nordeste'),
(83, 'aperreio', 'Confusão, preocupação.', 'Ex: Tive um aperreio no trabalho.', 'nordeste'),
(84, 'cabrunco', 'Algo muito difícil.', 'Ex: Esse trabalho tá cabrunco.', 'nordeste'),
(85, 'tabacudo', 'Pessoa boba ou atrapalhada.', 'Ex: Tu é muito tabacudo.', 'nordeste'),
(86, 'abestalhado', 'Bobo, besta.', 'Ex: Esse menino é abestalhado.', 'nordeste'),
(87, 'cabra da peste', 'Pessoa corajosa e forte.', 'Ex: Esse aí é cabra da peste!', 'nordeste'),
(88, 'fulero', 'Falso, de má qualidade.', 'Ex: Esse negócio é fulero.', 'nordeste'),
(89, 'arengueiro', 'Pessoa que provoca brigas.', 'Ex: Deixa de ser arengueiro.', 'nordeste'),
(90, 'invocado', 'Bravo ou admirado.', 'Ex: Ele ficou invocado.', 'nordeste'),
(91, 'embolado', 'Confuso.', 'Ex: O texto ficou embolado.', 'nordeste'),
(92, 'abirobado', 'Maluco.', 'Ex: Esse cara é abirobado.', 'nordeste'),
(93, 'bajulação', 'Puxa-saquismo.', 'Ex: Ele vive de bajulação.', 'nordeste'),
(94, 'fuleiro', 'Sem valor ou sem qualidade.', 'Ex: Esse carro é fuleiro.', 'nordeste'),
(95, 'aperreio', 'Enrascada.', 'Ex: Tô num aperreio danado.', 'nordeste'),
(96, 'matutar', 'Pensar muito.', 'Ex: Fiquei matutando nisso.', 'nordeste'),
(97, 'fuxico', 'Fofoquinha.', 'Ex: O povo tá no fuxico.', 'nordeste'),
(98, 'arriégua', 'Surpresa ou espanto.', 'Ex: Arriégua, que calor!', 'nordeste'),
(99, 'aperrear', 'Perturbar ou incomodar.', 'Ex: Pare de me aperrear.', 'nordeste'),
(100, 'visagem', 'Aparição.', 'Ex: Dizem que ali tem visagem.', 'nordeste'),
(101, 'estribado', 'Pessoa rica.', 'Ex: Ele é estribado.', 'nordeste'),
(102, 'mangar', 'Tirar sarro.', 'Ex: Mangaram de mim.', 'nordeste'),
(103, 'lambe-botas', 'Puxa-saco.', 'Ex: Ele é lambe-botas.', 'nordeste'),
(104, 'arengação', 'Discussão.', 'Ex: Teve uma arengação feia.', 'nordeste'),
(105, 'cabriola', 'Garoto levado.', 'Ex: Esse cabriola não para quieto.', 'nordeste'),
(106, 'fole', 'Pessoa preguiçosa.', 'Ex: Ele é um fole.', 'nordeste'),
(107, 'peste', 'Pessoa levada.', 'Ex: Menino peste!', 'nordeste'),
(108, 'ponga', 'Pessoa que se aproveita dos outros.', 'Ex: Ele é uma ponga.', 'nordeste'),
(109, 'pabuloso', 'Que se acha demais.', 'Ex: Tá todo pabuloso.', 'nordeste'),
(110, 'trupé', 'Balada, festa.', 'Ex: Vamos pro trupé hoje.', 'nordeste'),
(111, 'moído', 'Confusão grande.', 'Ex: Foi um moído só.', 'nordeste'),
(112, 'malassombro', 'Assombração.', 'Ex: Dizem que ali tem malassombro.', 'nordeste'),
(113, 'cabrunco', 'Algo difícil ou forte.', 'Ex: Esse exercício tá cabrunco.', 'nordeste'),
(114, 'engunço', 'Birra, antipatia.', 'Ex: Peguei engunço dele.', 'nordeste'),
(115, 'leso', 'Pessoa lenta, boba.', 'Ex: Tu é muito leso.', 'nordeste'),
(116, 'quenga', 'Mulher da vida.', 'Ex: Ele saiu com uma quenga.', 'nordeste'),
(117, 'abufelar', 'Cansar.', 'Ex: Andei demais e abufelei.', 'nordeste'),
(118, 'piau', 'Algo ruim, feito de qualquer jeito.', 'Ex: Esse trabalho ficou um piau.', 'centro-oeste'),
(119, 'arreda', 'Sai da frente, afastar.', 'Ex: Arreda aí, por favor.', 'centro-oeste'),
(120, 'butina', 'Bota, calçado resistente.', 'Ex: Calça a butina e vem.', 'centro-oeste'),
(121, 'piá', 'Criança, menino.', 'Ex: Esse piá é levado.', 'centro-oeste'),
(122, 'boleia', 'Carona.', 'Ex: Me dá uma boleia aí.', 'centro-oeste'),
(123, 'tramelar', 'Falar demais.', 'Ex: Para de tramelar.', 'centro-oeste'),
(124, 'gaiato', 'Brincalhão, bagunceiro.', 'Ex: Ele é todo gaiato.', 'centro-oeste'),
(125, 'xexelento', 'Velho, mal cuidado.', 'Ex: Esse carro tá xexelento.', 'centro-oeste'),
(126, 'minguado', 'Pouco, fraco.', 'Ex: O almoço veio minguado.', 'centro-oeste'),
(127, 'arredar o pé', 'Ir embora.', 'Ex: Já vou arredar o pé.', 'centro-oeste'),
(128, 'mofino', 'Triste, fraco.', 'Ex: Ele tá meio mofino.', 'centro-oeste'),
(129, 'amarrado', 'Trabalhoso.', 'Ex: Esse serviço tá amarrado.', 'centro-oeste'),
(130, 'bambeado', 'Solto, frouxo.', 'Ex: O parafuso tá bambeado.', 'centro-oeste'),
(131, 'bexiguento', 'Pessoa que implica por tudo.', 'Ex: Esse menino é bexiguento.', 'centro-oeste'),
(132, 'bodoso', 'Pessoa com mau cheiro.', 'Ex: Ele tá bodoso hoje.', 'centro-oeste'),
(133, 'catiripapo', 'Tapa forte.', 'Ex: Levou um catiripapo.', 'centro-oeste'),
(134, 'enxerido', 'Intrometido.', 'Ex: Para de ser enxerido.', 'centro-oeste'),
(135, 'perrengue', 'Dificuldade.', 'Ex: Passei um perrengue.', 'centro-oeste'),
(136, 'fofoca', 'Falar da vida alheia.', 'Ex: Tão na fofoca.', 'centro-oeste'),
(137, 'rebuliço', 'Agitação.', 'Ex: Deu um rebuliço na rua.', 'centro-oeste'),
(138, 'mandruvá', 'Pessoa lerda.', 'Ex: Ele é mandruvá demais.', 'centro-oeste'),
(139, 'butecão', 'Bar simples.', 'Ex: Vamos no butecão hoje.', 'centro-oeste'),
(140, 'trupicar', 'Tropeçar.', 'Ex: Trupiquei no degrau.', 'centro-oeste'),
(141, 'ôxe', 'Expressão de surpresa.', 'Ex: Ôxe, que é isso?', 'centro-oeste'),
(142, 'xexeiro', 'Pessoa que mexe onde não deve.', 'Ex: Não seja xexeiro.', 'centro-oeste'),
(143, 'dilícia', 'Algo muito gostoso.', 'Ex: Esse doce tá uma dilícia.', 'centro-oeste'),
(144, 'muriçoca', 'Mosquito.', 'Ex: Tem muita muriçoca hoje.', 'centro-oeste'),
(145, 'mimado', 'Manhoso.', 'Ex: Esse menino é mimado.', 'centro-oeste'),
(146, 'enferrujado', 'Sem prática.', 'Ex: Tô enferrujado nisso.', 'centro-oeste'),
(147, 'esbaforido', 'Cansado, ofegante.', 'Ex: Cheguei esbaforido.', 'centro-oeste'),
(148, 'fuzuê', 'Bagunça, confusão.', 'Ex: Teve um fuzuê na festa.', 'centro-oeste'),
(149, 'agoniado', 'Apressado, preocupado.', 'Ex: Tô agoniado demais.', 'centro-oeste'),
(150, 'tracina', 'Pessoa agitada.', 'Ex: Essa menina é uma tracina.', 'centro-oeste'),
(151, 'bucho', 'Barriga.', 'Ex: Tá com o bucho cheio.', 'centro-oeste'),
(152, 'embornal', 'Bolsa de pano.', 'Ex: Carrega no embornal.', 'centro-oeste'),
(153, 'mandingueiro', 'Pessoa supersticiosa.', 'Ex: Ele é meio mandingueiro.', 'centro-oeste'),
(154, 'cunhé', 'Expressão de espanto.', 'Ex: Cunhé, que susto!', 'centro-oeste'),
(155, 'trem', 'Coisa, objeto.', 'Ex: Me passa aquele trem ali.', 'centro-oeste'),
(156, 'boteco', 'Bar.', 'Ex: Tô no boteco.', 'centro-oeste'),
(157, 'bah', 'Expressão típica de surpresa, espanto ou admiração.', 'Ex: Bah, que baita notícia!', 'sul'),
(158, 'tri', 'Muito, legal.', 'Ex: O evento foi tri bom.', 'sul'),
(159, 'guri', 'Menino.', 'Ex: Esse guri é inteligente.', 'sul'),
(160, 'guria', 'Menina.', 'Ex: Aquela guria canta bem.', 'sul'),
(161, 'capaz', 'Expressão de negação ou incredulidade.', 'Ex: Capaz que isso é verdade!', 'sul'),
(162, 'barbaridade', 'Surpresa ou espanto forte.', 'Ex: Barbaridade, que frio!', 'sul'),
(163, 'bagual', 'Pessoa forte, rústica ou teimosa.', 'Ex: Ele é um bagual.', 'sul'),
(164, 'chinoca', 'Mulher jovem, namorada.', 'Ex: Levei a chinoca no baile.', 'sul'),
(165, 'prenda', 'Moça educada ou dama.', 'Ex: Aquela prenda dança muito.', 'sul'),
(166, 'piá', 'Menino, jovem.', 'Ex: O piá é esperto.', 'sul'),
(167, 'gaita', 'Acordeão.', 'Ex: Ele toca gaita bem.', 'sul'),
(168, 'macanudo', 'Muito bom, excelente.', 'Ex: O churrasco tava macanudo.', 'sul'),
(169, 'xucro', 'Bruto, não domesticado.', 'Ex: Ele é meio xucro.', 'sul'),
(170, 'grosso', 'Pessoa rude.', 'Ex: Para de ser grosso.', 'sul'),
(171, 'lagartear', 'Ficar ao sol descansando.', 'Ex: Vou lagartear um pouco.', 'sul'),
(172, 'borracho', 'Bêbado.', 'Ex: Ele ficou borracho.', 'sul'),
(173, 'tranco', 'Golpe, pancada.', 'Ex: Levou um tranco na porta.', 'sul'),
(174, 'gaudério', 'Pessoa do campo, típica do sul.', 'Ex: Ele é um gaudério.', 'sul'),
(175, 'cacetinho', 'Pão francês no Sul.', 'Ex: Compra um cacetinho ali.', 'sul'),
(176, 'velhaco', 'Esperto demais, malandro.', 'Ex: Aquele é velhaco.', 'sul'),
(177, 'fanho', 'Pessoa que fala pelo nariz.', 'Ex: Ele é meio fanho.', 'sul'),
(178, 'baita', 'Muito grande, muito bom.', 'Ex: Que baita susto!', 'sul'),
(179, 'negrinho do pastoreio', 'Figura folclórica.', 'Ex: Contaram história do Negrinho do Pastoreio.', 'sul'),
(180, 'galo véio', 'Pessoa experiente e malandra.', 'Ex: Ele é galo véio nesse negócio.', 'sul'),
(181, 'trilegal', 'Muito legal mesmo.', 'Ex: O jogo foi trilegal.', 'sul'),
(182, 'coruja', 'Pessoa que fica acordada até tarde.', 'Ex: Sou coruja demais.', 'sul'),
(183, 'entroncado', 'Forte fisicamente.', 'Ex: O cara é entroncado.', 'sul'),
(184, 'faceiro', 'Animado, feliz.', 'Ex: Tava faceiro hoje.', 'sul'),
(185, 'pinhão', 'Semente típica, comida.', 'Ex: Fiz pinhão cozido.', 'sul'),
(186, 'batelada', 'Grande quantidade.', 'Ex: Trouxe uma batelada de coisas.', 'sul'),
(187, 'cacetear', 'Perturbar muito.', 'Ex: Ele ficou me caceteando.', 'sul'),
(188, 'bodoco', 'Objeto improvisado.', 'Ex: Fiz um bodoco pra usar.', 'sul'),
(189, 'bugio', 'Dança tradicional gaúcha.', 'Ex: Dançaram bugio no CTG.', 'sul'),
(190, 'gringo', 'No Sul, pessoa de origem europeia local.', 'Ex: Ele é gringo daqui mesmo.', 'sul'),
(191, 'cariar', 'Enrolar, complicar.', 'Ex: Não me caria isso.', 'sul'),
(192, 'puxar o saco', 'Bajular.', 'Ex: Vive puxando o saco do chefe.', 'sul'),
(193, 'Bergamota', 'Tangerina.', 'Ex: Comprei vergamota.', 'sul'),
(194, 'barbaridade tchê', 'Surpresa forte, típica do RS.', 'Ex: Barbaridade tchê, que ventania!', 'sul');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `slangs`
--
ALTER TABLE `slangs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `slangs`
--
ALTER TABLE `slangs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=195;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
