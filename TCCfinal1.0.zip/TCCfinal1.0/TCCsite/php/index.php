<?php
require 'config.php';

function normalize($s) {
    $s = mb_strtolower(trim($s), 'UTF-8');
    $s = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
    $s = preg_replace('/[^a-z0-9 ]+/', '', $s);
    $s = preg_replace('/\s+/', ' ', $s);
    return $s;
}

$term = isset($_GET['q']) ? trim($_GET['q']) : '';
$threshold = isset($_GET['threshold']) ? floatval($_GET['threshold']) : 0.45;
$results = [];

if ($term !== '') {
    $termNorm = normalize($term);
    $like = '%' . str_replace(' ', '%', $termNorm) . '%';
    $stmt = $pdo->prepare("SELECT * FROM slangs WHERE normalized LIKE :like OR slang LIKE :like");
    $stmt->execute([':like' => $like]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($rows) < 1) {
        $stmtAll = $pdo->query("SELECT * FROM slangs");
        $rows = $stmtAll->fetchAll(PDO::FETCH_ASSOC);
    }

    foreach ($rows as $r) {
        $sNorm = normalize($r['slang'] . ' ' . $r['definition']);
        $distance = levenshtein($termNorm, $sNorm);
        $maxLen = max(mb_strlen($termNorm), mb_strlen($sNorm), 1);
        $similarity = 1 - ($distance / $maxLen);

        if (strpos($sNorm, $termNorm) !== false) {
            $similarity = max($similarity, 0.95);
        }

        $r['similarity'] = round($similarity, 3);
        $results[] = $r;
    }

    usort($results, fn($a, $b) => $b['similarity'] <=> $a['similarity']);
    $results = array_filter($results, fn($r) => $r['similarity'] >= $threshold);
    $results = array_slice($results, 0, 30);
}
?>
<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>Tradutor de Gírias Brasileiras</title>
<link rel="stylesheet" href="../css2/styleIndex.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>

<header>
  <div class="logo"><strong>T.V.L.B</strong></div>
  <nav>
    <a href="../Loading.html">Login</a>
    <a href="../contato.html">Contato</a>
    <a href="../Usuario.html">Usuario</a>
    <a href="../adiminLogin.html">Adimin</a>
  </nav>
</header>

<section class="search-section">
  <form method="get" action="" class="search-box">
    <input type="text" name="q" placeholder="Pesquise por gírias..." value="<?= htmlspecialchars($term) ?>">
    <button type="submit">🔍</button>
  </form>
</section>

<div class="container">
    <h1>Tradutor de Gírias Brasileiras</h1>

    <?php if ($term === ''): ?>
        <p>Digite uma palavra e clique em pesquisar.</p>
    <?php else: ?>
        <p>Resultados para <strong><?= htmlspecialchars($term) ?></strong> (<?= count($results) ?> encontrado(s))</p>
        <?php if (count($results) === 0): ?>
            <p><em>Nenhum resultado encontrado.</em></p>
        <?php else: ?>
            <?php foreach ($results as $r): ?>
            <div class="result">
                <strong><?= htmlspecialchars($r['slang']) ?></strong>
                <!-- <span class="badge"><?= htmlspecialchars($r['#']) ?></span> -->
                <p><?= htmlspecialchars($r['definition']) ?></p>
                <?php if (!empty($r['example'])): ?>
                <em><?= htmlspecialchars($r['example']) ?></em>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    <?php endif; ?>
</div>

<footer>
  <h2>📘 Tradutor de gírias brasileiras</h2>
  <p>Descubra a diversidade linguística do Brasil</p>
  <div class="socials">
    <a href="#"><img src="img/facebook.png" alt="face" class="socials1 Diz"></a >
    <a href="#"><img src="img/instagram.png" alt="insta" class="socials1 Diz2"></a>
    <a href="#"><img src="img/mail.png" alt="Comunica" class="socials1 Diz3"></a>
  </div>
</footer>

</body>
</html>
